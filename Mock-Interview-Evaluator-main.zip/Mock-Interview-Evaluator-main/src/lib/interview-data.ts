export interface InterviewQuestion {
  id: number;
  question: string;
  category: "behavioral" | "technical" | "situational";
  timeLimit: number; // seconds
}

export const interviewQuestions: InterviewQuestion[] = [
  {
    id: 1,
    question: "Tell me about yourself and why you're interested in this role.",
    category: "behavioral",
    timeLimit: 120,
  },
  {
    id: 2,
    question: "Describe a challenging project you worked on. What was your approach and outcome?",
    category: "behavioral",
    timeLimit: 150,
  },
  {
    id: 3,
    question: "How do you handle tight deadlines and pressure at work?",
    category: "situational",
    timeLimit: 120,
  },
  {
    id: 4,
    question: "Explain a technical concept you've recently learned to a non-technical person.",
    category: "technical",
    timeLimit: 150,
  },
  {
    id: 5,
    question: "Where do you see yourself in five years?",
    category: "behavioral",
    timeLimit: 120,
  },
  {
    id: 6,
    question: "Tell me about a time you disagreed with a team member. How did you resolve it?",
    category: "situational",
    timeLimit: 150,
  },
  {
    id: 7,
    question: "What's your approach to debugging a complex issue in production?",
    category: "technical",
    timeLimit: 150,
  },
];

export interface InterviewResult {
  id: string;
  date: string;
  candidateName: string;
  role: string;
  scores: {
    communication: number;
    confidence: number;
    technical: number;
    overall: number;
  };
  hiringProbability: number;
  feedback: string;
  answers: AnswerResult[];
}

export interface AnswerResult {
  questionId: number;
  question: string;
  transcript: string;
  score: number;
  feedback: string;
}

// Mock historical data for dashboard
export const mockInterviewHistory: InterviewResult[] = [
  {
    id: "1",
    date: "2026-03-08",
    candidateName: "Alex Johnson",
    role: "Frontend Developer",
    scores: { communication: 82, confidence: 75, technical: 88, overall: 82 },
    hiringProbability: 78,
    feedback: "Strong technical skills with room to improve confidence in behavioral questions.",
    answers: [],
  },
  {
    id: "2",
    date: "2026-03-07",
    candidateName: "Sarah Chen",
    role: "Product Manager",
    scores: { communication: 91, confidence: 88, technical: 72, overall: 84 },
    hiringProbability: 85,
    feedback: "Excellent communication and leadership examples. Could strengthen technical depth.",
    answers: [],
  },
  {
    id: "3",
    date: "2026-03-05",
    candidateName: "Marcus Williams",
    role: "Data Scientist",
    scores: { communication: 70, confidence: 65, technical: 94, overall: 77 },
    hiringProbability: 72,
    feedback: "Exceptional technical knowledge but needs to work on articulating complex ideas clearly.",
    answers: [],
  },
  {
    id: "4",
    date: "2026-03-03",
    candidateName: "Emily Park",
    role: "UX Designer",
    scores: { communication: 88, confidence: 82, technical: 79, overall: 83 },
    hiringProbability: 81,
    feedback: "Great portfolio discussion and design thinking approach. Solid candidate overall.",
    answers: [],
  },
];
