import { InterviewResult, mockInterviewHistory } from "./interview-data";

const STORAGE_KEY = "mock_interview_history";

export const getInterviewHistory = (): InterviewResult[] => {
  if (typeof window === "undefined") return mockInterviewHistory;
  
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    // Seed with mock data from interview-data.ts on first run
    saveInterviewHistory(mockInterviewHistory);
    return mockInterviewHistory;
  }
  
  try {
    return JSON.parse(stored);
  } catch (e) {
    console.error("Error parsing stored interview history", e);
    return mockInterviewHistory;
  }
};

export const saveInterviewHistory = (history: InterviewResult[]) => {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
};

export const addInterviewResult = (result: Omit<InterviewResult, "id" | "date">): InterviewResult => {
  const history = getInterviewHistory();
  const newResult: InterviewResult = {
    ...result,
    id: String(Date.now()),
    date: new Date().toISOString().split("T")[0],
  };
  
  const updated = [newResult, ...history];
  saveInterviewHistory(updated);
  return newResult;
};
