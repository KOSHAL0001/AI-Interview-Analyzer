import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Mic, 
  MicOff, 
  Clock, 
  ArrowRight, 
  CheckCircle, 
  Play, 
  Video, 
  Sparkles, 
  Loader2, 
  Cpu, 
  BookOpen, 
  HelpCircle,
  TrendingUp,
  AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { InterviewQuestion } from "@/lib/interview-data";
import InterviewResults from "@/components/InterviewResults";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

type Phase = "intro" | "recording" | "results";
type DurationMode = "10min" | "30min" | "1hour" | "endless";

const PRESET_ROLES = [
  "Frontend Developer",
  "Backend Developer",
  "Full Stack Developer",
  "Mobile App Developer",
  "DevOps Engineer",
  "Data Scientist",
  "Product Manager",
  "UX/UI Designer",
  "Other (Custom)"
];

const INTERVIEW_TIPS = [
  "Use the STAR method (Situation, Task, Action, Result) to structure your answers.",
  "Speak clearly and at a moderate pace. AI evaluates articulation and word choice.",
  "Maintain eye contact with your webcam to convey confidence and engagement.",
  "Highlight technical trade-offs and decision-making rationale when answering technical questions.",
  "Don't worry about stumbling. Be calm, correct yourself, and explain your thought process.",
];

// High quality client-side fallback question generator
function generateLocalQuestions(role: string, techStack: string, count: number): InterviewQuestion[] {
  const stackList = techStack ? techStack.split(",").map(s => s.trim()) : ["industry best practices"];
  const primaryTech = stackList[0];
  const secondaryTech = stackList[1] || "modern software design";

  const behavioralPool = [
    `Tell me about yourself and what draws you specifically to the ${role} position.`,
    `Describe a complex project you worked on involving ${primaryTech}. What challenges did you face and how did you overcome them?`,
    `How do you prioritize tasks and manage tight deadlines when building applications with ${secondaryTech}?`,
    `Tell me about a time you had a technical disagreement with a colleague or stakeholder (e.g. regarding ${primaryTech}). How was it resolved?`,
    `Where do you see yourself growing technically and professionally as a ${role} in the next three years?`
  ];

  const technicalPool = [
    `Explain the fundamental architecture and performance model of ${primaryTech}. How do you optimize its efficiency?`,
    `What strategies do you adopt for modularity, testing, and clean code when developing a system using ${techStack || "your target stack"}?`,
    `In your experience as a ${role}, how do you manage state, concurrency, or data consistency when working with ${primaryTech}?`,
    `Explain a highly complex topic within ${primaryTech} to a non-technical stakeholder in simple, intuitive terms.`,
    `Describe your methodology for diagnosing and resolving a high-severity production issue in a service using ${primaryTech}.`
  ];

  const situationalPool = [
    `Suppose a production system using ${primaryTech} goes live and immediately experiences a severe regression or memory leak. How would you debug this?`,
    `If you were tasked with migrating a major legacy application to ${techStack || "your target stack"}, how would you structure the migration to minimize downtime?`,
    `Imagine a team member consistently merges code in ${primaryTech} that bypasses tests or quality standards. How do you handle this?`,
    `You are asked to integrate an critical backend dependency with ${primaryTech} under an extremely unrealistic deadline. What is your response?`
  ];

  const questions: InterviewQuestion[] = [];
  
  for (let i = 0; i < count; i++) {
    let category: "behavioral" | "technical" | "situational";
    let pool: string[];
    
    if (i % 3 === 0) {
      category = "behavioral";
      pool = behavioralPool;
    } else if (i % 3 === 1) {
      category = "technical";
      pool = technicalPool;
    } else {
      category = "situational";
      pool = situationalPool;
    }

    const questionText = pool[Math.floor(i / 3) % pool.length];
    
    questions.push({
      id: i + 1,
      question: questionText,
      category,
      timeLimit: category === "technical" ? 150 : 120
    });
  }

  return questions;
}

export default function Interview() {
  const [phase, setPhase] = useState<Phase>("intro");
  
  // Customization States
  const [selectedRole, setSelectedRole] = useState("Frontend Developer");
  const [customRole, setCustomRole] = useState("");
  const [techStack, setTechStack] = useState("");
  const [durationMode, setDurationMode] = useState<DurationMode>("10min");
  const [candidateName, setCandidateName] = useState("");
  
  // Question & Session States
  const [questions, setQuestions] = useState<InterviewQuestion[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [loadingQuestions, setLoadingQuestions] = useState(false);
  const [currentTip, setCurrentTip] = useState(INTERVIEW_TIPS[0]);
  
  // Recording States
  const [isRecording, setIsRecording] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [frames, setFrames] = useState<string[][]>([]); // frames per question (data URLs)
  const [currentTranscript, setCurrentTranscript] = useState("");
  
  // Refs
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const recognitionRef = useRef<any>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const frameIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const currentFramesRef = useRef<string[]>([]);

  const question = questions[currentQ] || { id: 1, question: "", category: "behavioral", timeLimit: 120 };

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (frameIntervalRef.current) {
      clearInterval(frameIntervalRef.current);
      frameIntervalRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      stopTimer();
      stopCamera();
    };
  }, [stopTimer, stopCamera]);

  // Bind video stream to the video element when the recording phase mounts it
  useEffect(() => {
    if (phase === "recording" && streamRef.current && videoRef.current) {
      videoRef.current.srcObject = streamRef.current;
      videoRef.current.play().catch((err) => console.error("Error playing video:", err));
    }
  }, [phase]);

  // Cycle tips during loading
  useEffect(() => {
    if (!loadingQuestions) return;
    let tipIdx = 0;
    const interval = setInterval(() => {
      tipIdx = (tipIdx + 1) % INTERVIEW_TIPS.length;
      setCurrentTip(INTERVIEW_TIPS[tipIdx]);
    }, 5000);
    return () => clearInterval(interval);
  }, [loadingQuestions]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480, facingMode: "user" },
        audio: true,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      return true;
    } catch (e) {
      toast.error("Camera/microphone access denied. Please grant permissions to conduct the video interview.");
      return false;
    }
  };

  const captureFrame = (): string | null => {
    const video = videoRef.current;
    if (!video || video.videoWidth === 0) return null;
    const canvas = document.createElement("canvas");
    const w = 320;
    const h = Math.round((video.videoHeight / video.videoWidth) * w);
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, w, h);
    return canvas.toDataURL("image/jpeg", 0.6);
  };

  // Helper to fetch questions from Edge Function or fallback
  const fetchQuestions = async (
    role: string, 
    techStack: string, 
    count: number,
    existing: string[] = []
  ): Promise<InterviewQuestion[]> => {
    try {
      const { data, error } = await supabase.functions.invoke("generate-questions", {
        body: { role, techStack, count, existingQuestions: existing },
      });
      
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      if (data?.questions && Array.isArray(data.questions) && data.questions.length > 0) {
        return data.questions;
      }
      throw new Error("Invalid response format");
    } catch (e) {
      console.warn("Edge function invocation failed, falling back to local question generator:", e);
      return generateLocalQuestions(role, techStack, count);
    }
  };

  const handleStartInterview = async () => {
    const role = selectedRole === "Other (Custom)" ? customRole : selectedRole;
    if (selectedRole === "Other (Custom)" && !customRole.trim()) {
      toast.error("Please enter a custom Job Role.");
      return;
    }

    setLoadingQuestions(true);

    let initialCount = 5;
    if (durationMode === "10min") initialCount = 3;
    else if (durationMode === "30min") initialCount = 8;
    else if (durationMode === "1hour") initialCount = 15;
    else if (durationMode === "endless") initialCount = 3; // Start with 3, load more on-the-fly

    try {
      // Warm up camera permission check concurrently
      const cameraOk = await startCamera();
      if (!cameraOk) {
        setLoadingQuestions(false);
        return;
      }

      const generated = await fetchQuestions(role, techStack, initialCount);
      setQuestions(generated);
      setCurrentQ(0);
      setAnswers([]);
      setFrames([]);
      setPhase("recording");
    } catch (e) {
      toast.error("Failed to set up interview. Please try again.");
    } finally {
      setLoadingQuestions(false);
    }
  };

  const startRecording = () => {
    setCurrentTranscript("");
    setIsRecording(true);
    setTimeLeft(question.timeLimit);
    currentFramesRef.current = [];

    // Capture a frame every 2.5 seconds (max ~8 frames per answer)
    frameIntervalRef.current = setInterval(() => {
      const frame = captureFrame();
      if (frame && currentFramesRef.current.length < 8) {
        currentFramesRef.current.push(frame);
      }
    }, 2500);
    // Capture one immediately
    setTimeout(() => {
      const f = captureFrame();
      if (f) currentFramesRef.current.push(f);
    }, 300);

    // Use Web Speech API for speech-to-text
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";
      let finalTranscript = "";

      recognition.onresult = (event: any) => {
        let interim = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript + " ";
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        setCurrentTranscript(finalTranscript + interim);
      };
      recognition.start();
      recognitionRef.current = recognition;
    }

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          stopRecordingAndNext();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const stopRecordingAndNext = async () => {
    setIsRecording(false);
    stopTimer();
    if (frameIntervalRef.current) {
      clearInterval(frameIntervalRef.current);
      frameIntervalRef.current = null;
    }
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      recognitionRef.current = null;
    }

    const capturedFrames = [...currentFramesRef.current];
    currentFramesRef.current = [];

    const currentAns = currentTranscript || "(No speech detected)";
    const updatedAnswers = [...answers, currentAns];
    setAnswers(updatedAnswers);
    setFrames((prev) => [...prev, capturedFrames]);

    const isLastQuestion = currentQ >= questions.length - 1;

    if (isLastQuestion) {
      if (durationMode === "endless") {
        setLoadingQuestions(true);
        const role = selectedRole === "Other (Custom)" ? customRole : selectedRole;
        try {
          const currentList = [...questions.map(q => q.question)];
          const nextBatch = await fetchQuestions(role, techStack, 3, currentList);
          
          setQuestions((prev) => {
            const mappedBatch = nextBatch.map((q, idx) => ({
              ...q,
              id: prev.length + idx + 1
            }));
            return [...prev, ...mappedBatch];
          });
          
          setCurrentQ((prev) => prev + 1);
          setCurrentTranscript("");
          toast.success("Successfully generated next batch of custom questions!");
        } catch (err) {
          toast.error("Failed to generate custom endless questions, checking local templates...");
          const nextBatch = generateLocalQuestions(role, techStack, 3);
          setQuestions((prev) => {
            const mappedBatch = nextBatch.map((q, idx) => ({
              ...q,
              id: prev.length + idx + 1
            }));
            return [...prev, ...mappedBatch];
          });
          setCurrentQ((prev) => prev + 1);
          setCurrentTranscript("");
        } finally {
          setLoadingQuestions(false);
        }
      } else {
        // Last question in standard modes - go to results
        setTimeout(() => {
          stopCamera();
          setPhase("results");
        }, 500);
      }
    } else {
      setCurrentQ((prev) => prev + 1);
      setCurrentTranscript("");
    }
  };

  const handleFinishInterviewEarly = () => {
    stopCamera();
    stopTimer();
    setPhase("results");
    toast.success("Interview completed! Analyzing your responses...");
  };

  const formatTime = (s: number) =>
    `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;

  if (phase === "results") {
    return (
      <InterviewResults 
        questions={questions} 
        answers={answers} 
        frames={frames} 
        role={selectedRole === "Other (Custom)" ? customRole : selectedRole}
        candidateName={candidateName.trim() || "Candidate"}
      />
    );
  }

  if (phase === "intro") {
    return (
      <div className="p-4 md:p-8 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card rounded-2xl p-6 md:p-8 card-shadow-prominent border border-border relative overflow-hidden"
        >
          {/* Decorative gradients */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-primary/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20" />

          {/* Form Header */}
          <div className="text-center mb-8 relative">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-7 h-7 text-primary" />
            </div>
            <h1 className="text-3xl font-display font-bold text-card-foreground">
              Configure Your Mock Interview
            </h1>
            <p className="text-muted-foreground text-sm max-w-md mx-auto mt-2">
              Customize your experience. Our AI will dynamically generate real-world questions based on your targeting.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 relative">
            {/* Left side: Role & Stack */}
            <div className="space-y-5">
              <div>
                <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block mb-2">
                  Your Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. John Doe"
                  value={candidateName}
                  onChange={(e) => setCandidateName(e.target.value)}
                  className="w-full h-11 bg-background border border-border rounded-xl px-3.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary transition"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block mb-2">
                  Target Job Role
                </label>
                <select
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full h-11 bg-background border border-border rounded-xl px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary transition"
                >
                  {PRESET_ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <AnimatePresence mode="wait">
                {selectedRole === "Other (Custom)" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block mb-2">
                      Specify Job Role
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Senior Staff Engineer"
                      value={customRole}
                      onChange={(e) => setCustomRole(e.target.value)}
                      className="w-full h-11 bg-background border border-border rounded-xl px-3.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary transition"
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              <div>
                <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block mb-2">
                  Tech Stack / Focus Skills (Comma Separated)
                </label>
                <input
                  type="text"
                  placeholder="e.g. React, TypeScript, Tailwind, Node.js"
                  value={techStack}
                  onChange={(e) => setTechStack(e.target.value)}
                  className="w-full h-11 bg-background border border-border rounded-xl px-3.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary transition"
                />
                <span className="text-[11px] text-muted-foreground mt-1 block">
                  Leave empty for generic questions matching the role.
                </span>
              </div>
            </div>

            {/* Right side: Benefits checklist */}
            <div className="bg-secondary/40 rounded-xl p-5 border border-border/50 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-semibold text-card-foreground mb-3 flex items-center gap-1.5">
                  <Cpu className="w-4 h-4 text-primary" />
                  What to Expect
                </h3>
                <ul className="text-xs text-muted-foreground space-y-3">
                  <li className="flex items-start gap-2.5">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                    <span><strong>Tailored Questions:</strong> AI generates questions targeting your exact specifications.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                    <span><strong>Speech & Facial Analysis:</strong> Webcam frame captures evaluate confidence and clarity.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                    <span><strong>Actionable Report:</strong> Instantly export a comprehensive performance PDF report.</span>
                  </li>
                </ul>
              </div>
              <div className="mt-5 border-t border-border pt-4 flex items-center gap-2 text-xs text-muted-foreground">
                <AlertTriangle className="w-4 h-4 text-warning shrink-0" />
                <span>Make sure camera and microphone permissions are enabled.</span>
              </div>
            </div>
          </div>

          {/* Duration choice selector */}
          <div className="mb-8 relative">
            <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block mb-3">
              Select Interview Duration & Format
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
              {/* Option 1: 10 mins */}
              <div
                onClick={() => setDurationMode("10min")}
                className={`cursor-pointer rounded-xl p-4 border transition flex flex-col justify-between h-[115px] select-none ${
                  durationMode === "10min"
                    ? "border-primary bg-primary/5 shadow-sm shadow-primary/10"
                    : "border-border bg-card hover:bg-secondary/30"
                }`}
              >
                <div>
                  <h4 className="text-sm font-display font-bold text-foreground">10 Minutes</h4>
                  <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">
                    Rapid check. Perfect for quick mock prep.
                  </p>
                </div>
                <span className="text-[11px] font-medium text-primary bg-primary/10 rounded-full px-2 py-0.5 self-start">
                  3 Questions
                </span>
              </div>

              {/* Option 2: 30 mins */}
              <div
                onClick={() => setDurationMode("30min")}
                className={`cursor-pointer rounded-xl p-4 border transition flex flex-col justify-between h-[115px] select-none ${
                  durationMode === "30min"
                    ? "border-primary bg-primary/5 shadow-sm shadow-primary/10"
                    : "border-border bg-card hover:bg-secondary/30"
                }`}
              >
                <div>
                  <h4 className="text-sm font-display font-bold text-foreground">30 Minutes</h4>
                  <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">
                    Standard mock. Fully evaluates skills.
                  </p>
                </div>
                <span className="text-[11px] font-medium text-primary bg-primary/10 rounded-full px-2 py-0.5 self-start">
                  8 Questions
                </span>
              </div>

              {/* Option 3: 1 hour */}
              <div
                onClick={() => setDurationMode("1hour")}
                className={`cursor-pointer rounded-xl p-4 border transition flex flex-col justify-between h-[115px] select-none ${
                  durationMode === "1hour"
                    ? "border-primary bg-primary/5 shadow-sm shadow-primary/10"
                    : "border-border bg-card hover:bg-secondary/30"
                }`}
              >
                <div>
                  <h4 className="text-sm font-display font-bold text-foreground">1 Hour</h4>
                  <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">
                    Comprehensive. Deep dive technical loop.
                  </p>
                </div>
                <span className="text-[11px] font-medium text-primary bg-primary/10 rounded-full px-2 py-0.5 self-start">
                  15 Questions
                </span>
              </div>

              {/* Option 4: Endless */}
              <div
                onClick={() => setDurationMode("endless")}
                className={`cursor-pointer rounded-xl p-4 border transition flex flex-col justify-between h-[115px] select-none ${
                  durationMode === "endless"
                    ? "border-accent bg-accent/5 shadow-sm shadow-accent/10"
                    : "border-border bg-card hover:bg-secondary/30"
                }`}
              >
                <div>
                  <h4 className="text-sm font-display font-bold text-foreground flex items-center gap-1">
                    Endless Mode
                    <Sparkles className="w-3.5 h-3.5 text-accent animate-pulse" />
                  </h4>
                  <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">
                    Unlimited questions. Finish when you choose!
                  </p>
                </div>
                <span className="text-[11px] font-medium text-accent bg-accent/10 rounded-full px-2 py-0.5 self-start">
                  Endless Questions
                </span>
              </div>
            </div>
          </div>

          <Button
            onClick={handleStartInterview}
            className="w-full py-6 text-base rounded-xl font-medium flex items-center justify-center gap-2 transition"
          >
            <Video className="w-5 h-5 shrink-0" />
            Enable Camera & Generate Interview
          </Button>
        </motion.div>

        {/* Global configuration loader overlay */}
        <AnimatePresence>
          {loadingQuestions && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4"
            >
              <motion.div
                initial={{ scale: 0.95 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.95 }}
                className="bg-card max-w-md w-full rounded-2xl p-8 border border-border text-center card-shadow-prominent"
              >
                <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto mb-5" />
                <h3 className="text-xl font-display font-bold text-card-foreground mb-2">
                  Building Your Personalized Interview
                </h3>
                <p className="text-muted-foreground text-sm mb-6">
                  Generating realistic questions for <strong className="text-primary">{selectedRole === "Other (Custom)" ? customRole : selectedRole}</strong>...
                </p>

                {/* Rotating tip block */}
                <div className="bg-secondary/40 rounded-xl p-4.5 text-left border border-border/50 min-h-[100px] flex flex-col justify-center">
                  <span className="text-[10px] font-semibold text-primary uppercase tracking-wider block mb-1">
                    Interview Tip
                  </span>
                  <p className="text-xs text-secondary-foreground leading-relaxed">
                    {currentTip}
                  </p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 max-w-3xl mx-auto">
      {/* Header and Progress block */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-muted-foreground">
            {durationMode === "endless" ? (
              <span className="flex items-center gap-1 text-accent font-semibold">
                Question {currentQ + 1}
                <span className="text-xs px-2 py-0.5 bg-accent/10 text-accent rounded-full border border-accent/20">
                  Endless Mode
                </span>
              </span>
            ) : (
              <span>
                Question <strong className="text-primary font-bold">{currentQ + 1}</strong> of <strong>{questions.length}</strong>
              </span>
            )}
          </span>
          <span className="text-xs font-semibold px-2.5 py-1 bg-secondary text-secondary-foreground rounded-full capitalize">
            {question.category}
          </span>
        </div>
        
        {durationMode !== "endless" && (
          <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-primary rounded-full"
              animate={{ width: `${((currentQ + 1) / questions.length) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        )}
      </motion.div>

      {/* Video Webcam Stream Window */}
      <div className="relative mb-5 rounded-2xl overflow-hidden bg-black aspect-video border border-border card-shadow-elevated">
        <video ref={videoRef} muted playsInline className="w-full h-full object-cover -scale-x-100" />
        {isRecording && (
          <div className="absolute top-4 left-4 flex items-center gap-1.5 bg-destructive/90 text-destructive-foreground text-xs font-semibold px-2.5 py-1 rounded-full animate-pulse shadow-sm">
            <span className="w-2 h-2 rounded-full bg-white" />
            RECORDING ACTIVE
          </div>
        )}
        
        {/* Loader overlay for generating endless questions */}
        <AnimatePresence>
          {loadingQuestions && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm z-10 flex items-center justify-center flex-col">
              <Loader2 className="w-10 h-10 text-accent animate-spin mb-2" />
              <p className="text-accent text-sm font-semibold">Generating next endless questions...</p>
            </div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentQ}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          className="bg-card rounded-2xl p-6 md:p-8 card-shadow-prominent border border-border relative overflow-hidden"
        >
          {/* Question Category Label */}
          <span className="text-[10px] font-bold text-primary uppercase tracking-wider block mb-2">
            Target Category: {question.category}
          </span>
          <h2 className="text-xl md:text-2xl font-display font-bold text-card-foreground mb-6 leading-normal">
            {question.question}
          </h2>

          {isRecording && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
              <Clock className="w-4 h-4 text-primary shrink-0" />
              <span className="font-mono text-foreground font-semibold">Remaining time: {formatTime(timeLeft)}</span>
            </div>
          )}

          {currentTranscript && (
            <div className="bg-secondary/50 border border-border/60 rounded-xl p-4.5 mb-6 text-sm text-secondary-foreground min-h-[70px] relative">
              <p className="text-[10px] font-bold text-muted-foreground/80 uppercase tracking-wider mb-1.5">
                Speech to Text (Live Preview):
              </p>
              <p className="italic text-foreground">{currentTranscript}</p>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {!isRecording ? (
                <Button onClick={startRecording} className="gap-2 px-5 py-5 rounded-xl font-medium shadow-sm shadow-primary/20">
                  <Mic className="w-4 h-4 shrink-0" />
                  Start Recording
                </Button>
              ) : (
                <Button
                  onClick={stopRecordingAndNext}
                  variant="destructive"
                  className="gap-2 px-5 py-5 rounded-xl font-medium shadow-sm shadow-destructive/20"
                >
                  <MicOff className="w-4 h-4 shrink-0" />
                  Stop & {currentQ < questions.length - 1 || durationMode === "endless" ? "Next Question" : "Finish Interview"}
                </Button>
              )}
            </div>

            {/* Finish Interview Early trigger */}
            <Button
              onClick={handleFinishInterviewEarly}
              variant="outline"
              className="border-border hover:bg-secondary/40 font-medium px-4 py-5 rounded-xl text-xs"
            >
              Finish Interview early
            </Button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
