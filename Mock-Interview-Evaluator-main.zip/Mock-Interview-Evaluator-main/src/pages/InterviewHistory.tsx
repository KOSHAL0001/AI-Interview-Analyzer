import { motion } from "framer-motion";
import { Calendar, User, Briefcase, TrendingUp } from "lucide-react";
import { getInterviewHistory } from "@/lib/interview-storage";

export default function InterviewHistory() {
  const history = getInterviewHistory();
  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">Interview History</h1>
        <p className="text-muted-foreground mt-1">Review past interview performances</p>
      </motion.div>

      <div className="space-y-4">
        {history.map((interview, i) => (
          <motion.div
            key={interview.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-card rounded-xl p-5 card-shadow-elevated border border-border"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold text-card-foreground">
                      {interview.candidateName}
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Briefcase className="w-3 h-3" />
                        {interview.role}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {interview.date}
                      </span>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mt-2">{interview.feedback}</p>
              </div>

              <div className="flex items-center gap-4 md:gap-6">
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Comm.</p>
                  <p className="text-lg font-display font-bold text-primary">{interview.scores.communication}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Conf.</p>
                  <p className="text-lg font-display font-bold text-accent">{interview.scores.confidence}</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground">Tech.</p>
                  <p className="text-lg font-display font-bold text-warning">{interview.scores.technical}</p>
                </div>
                <div className="text-center border-l border-border pl-4">
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" />
                    Hire %
                  </p>
                  <p className="text-lg font-display font-bold text-card-foreground">{interview.hiringProbability}%</p>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
