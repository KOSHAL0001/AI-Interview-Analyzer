import { motion } from "framer-motion";
import { getInterviewHistory } from "@/lib/interview-storage";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const COLORS = ["hsl(var(--primary))", "hsl(var(--accent))", "hsl(var(--warning))"];

export default function Analytics() {
  const history = getInterviewHistory();

  const trendData = history
    .slice()
    .reverse()
    .map((r) => ({
      name: r.candidateName.split(" ")[0] || "Guest",
      communication: r.scores.communication,
      confidence: r.scores.confidence,
      technical: r.scores.technical,
      overall: r.scores.overall,
    }));

  const avgScores = {
    communication: history.length > 0 
      ? Math.round(history.reduce((s, r) => s + r.scores.communication, 0) / history.length) 
      : 0,
    confidence: history.length > 0 
      ? Math.round(history.reduce((s, r) => s + r.scores.confidence, 0) / history.length) 
      : 0,
    technical: history.length > 0 
      ? Math.round(history.reduce((s, r) => s + r.scores.technical, 0) / history.length) 
      : 0,
  };

  const pieData = [
    { name: "Communication", value: avgScores.communication },
    { name: "Confidence", value: avgScores.confidence },
    { name: "Technical", value: avgScores.technical },
  ];
  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">Analytics</h1>
        <p className="text-muted-foreground mt-1">Deep dive into performance metrics</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-card rounded-xl p-6 card-shadow-elevated border border-border"
        >
          <h3 className="text-sm font-medium text-muted-foreground mb-4">Score Trends Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
              <YAxis tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} domain={[0, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
              />
              <Line type="monotone" dataKey="communication" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 4 }} name="Communication" />
              <Line type="monotone" dataKey="confidence" stroke="hsl(var(--accent))" strokeWidth={2} dot={{ r: 4 }} name="Confidence" />
              <Line type="monotone" dataKey="technical" stroke="hsl(var(--warning))" strokeWidth={2} dot={{ r: 4 }} name="Technical" />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card rounded-xl p-6 card-shadow-elevated border border-border"
        >
          <h3 className="text-sm font-medium text-muted-foreground mb-4">Average Score Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {pieData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-4 mt-2">
            {pieData.map((entry, i) => (
              <div key={entry.name} className="flex items-center gap-2 text-xs text-muted-foreground">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                {entry.name}: {entry.value}
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Improvement Tips */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-card rounded-xl p-6 card-shadow-elevated border border-border"
      >
        <h3 className="text-sm font-medium text-muted-foreground mb-4">AI-Generated Improvement Suggestions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-primary/5 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-primary mb-2">Communication</h4>
            <p className="text-xs text-muted-foreground">
              Practice the STAR method for behavioral questions. Record yourself and review for filler words.
            </p>
          </div>
          <div className="bg-accent/5 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-accent mb-2">Confidence</h4>
            <p className="text-xs text-muted-foreground">
              Maintain eye contact, use confident body language, and avoid self-deprecating qualifiers.
            </p>
          </div>
          <div className="bg-warning/5 rounded-lg p-4">
            <h4 className="text-sm font-semibold text-warning mb-2">Technical</h4>
            <p className="text-xs text-muted-foreground">
              Practice explaining technical concepts simply. Use real project examples to demonstrate expertise.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
