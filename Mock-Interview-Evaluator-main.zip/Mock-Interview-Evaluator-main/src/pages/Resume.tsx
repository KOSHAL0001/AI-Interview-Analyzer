import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Upload, FileText, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ResumeAnalysis {
  name: string;
  skills: string[];
  experience: string[];
  education: string[];
  score: number;
  suggestions: string[];
}

export default function Resume() {
  const [file, setFile] = useState<File | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ResumeAnalysis | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const f = e.dataTransfer.files[0];
    if (f?.type === "application/pdf") setFile(f);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) setFile(f);
  };

  const analyzeResume = () => {
    setAnalyzing(true);
    // Simulated analysis
    setTimeout(() => {
      setResult({
        name: file?.name.replace(".pdf", "") || "Candidate",
        skills: ["JavaScript", "React", "TypeScript", "Node.js", "Python", "SQL", "Git"],
        experience: [
          "3+ years full-stack development",
          "Led team of 4 engineers",
          "Built microservices architecture",
        ],
        education: ["B.S. Computer Science, State University"],
        score: 78,
        suggestions: [
          "Add quantifiable metrics to your achievements (e.g., 'Improved load time by 40%')",
          "Include links to portfolio or GitHub profile",
          "Consider adding a brief professional summary at the top",
          "List relevant certifications if any",
        ],
      });
      setAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">Resume Analyzer</h1>
        <p className="text-muted-foreground mt-1">Upload your resume for AI-powered analysis</p>
      </motion.div>

      {!result ? (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            onClick={() => inputRef.current?.click()}
            className="bg-card rounded-xl p-12 card-shadow-elevated border-2 border-dashed border-border hover:border-primary/50 transition-colors cursor-pointer text-center"
          >
            <input ref={inputRef} type="file" accept=".pdf" className="hidden" onChange={handleFileSelect} />
            <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-card-foreground font-medium mb-1">
              {file ? file.name : "Drop your resume PDF here"}
            </p>
            <p className="text-sm text-muted-foreground">or click to browse</p>
          </div>

          {file && (
            <div className="mt-4 flex items-center justify-between bg-card rounded-lg p-4 border border-border">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-primary" />
                <span className="text-sm text-card-foreground">{file.name}</span>
              </div>
              <Button onClick={analyzeResume} disabled={analyzing}>
                {analyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  "Analyze Resume"
                )}
              </Button>
            </div>
          )}
        </motion.div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          {/* Resume Score */}
          <div className="bg-card rounded-xl p-6 card-shadow-elevated border border-border">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-display font-semibold text-card-foreground">Resume Score</h3>
              <span className="text-3xl font-display font-bold text-primary">{result.score}/100</span>
            </div>
            <div className="w-full h-3 bg-secondary rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${result.score}%` }}
                transition={{ duration: 0.8 }}
                className="h-full bg-primary rounded-full"
              />
            </div>
          </div>

          {/* Skills */}
          <div className="bg-card rounded-xl p-6 card-shadow-elevated border border-border">
            <h3 className="text-sm font-medium text-muted-foreground mb-3">Detected Skills</h3>
            <div className="flex flex-wrap gap-2">
              {result.skills.map((skill) => (
                <span key={skill} className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full font-medium">
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Experience */}
          <div className="bg-card rounded-xl p-6 card-shadow-elevated border border-border">
            <h3 className="text-sm font-medium text-muted-foreground mb-3">Experience Highlights</h3>
            <ul className="space-y-2">
              {result.experience.map((exp, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-card-foreground">
                  <CheckCircle className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                  {exp}
                </li>
              ))}
            </ul>
          </div>

          {/* Suggestions */}
          <div className="bg-card rounded-xl p-6 card-shadow-elevated border border-border">
            <h3 className="text-sm font-medium text-muted-foreground mb-3">Improvement Suggestions</h3>
            <ul className="space-y-2">
              {result.suggestions.map((s, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-card-foreground">
                  <AlertCircle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
                  {s}
                </li>
              ))}
            </ul>
          </div>

          <Button variant="outline" onClick={() => { setResult(null); setFile(null); }}>
            Upload Another Resume
          </Button>
        </motion.div>
      )}
    </div>
  );
}
