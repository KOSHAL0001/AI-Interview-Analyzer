import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  MessageSquare,
  Shield,
  Zap,
  TrendingUp,
  ArrowRight,
  Users,
  Clock,
  Target,
} from "lucide-react";
import ScoreCard from "@/components/ScoreCard";
import HiringProbabilityGauge from "@/components/HiringProbabilityGauge";
import { getInterviewHistory } from "@/lib/interview-storage";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";

export default function Dashboard() {
  const history = getInterviewHistory();
  const latestResult = history[0] || {
    candidateName: "Guest",
    scores: { communication: 0, confidence: 0, technical: 0, overall: 0 },
    hiringProbability: 0
  };

  const radarData = [
    { subject: "Communication", value: latestResult.scores.communication },
    { subject: "Confidence", value: latestResult.scores.confidence },
    { subject: "Technical", value: latestResult.scores.technical },
    { subject: "Clarity", value: Math.max(70, Math.round(latestResult.scores.communication * 0.95)) },
    { subject: "Problem Solving", value: Math.max(75, Math.round(latestResult.scores.technical * 0.98)) },
  ];

  const trendData = history
    .slice()
    .reverse()
    .map((r) => ({
      name: r.candidateName.split(" ")[0] || "Guest",
      score: r.scores.overall,
      hiring: r.hiringProbability,
    }));

  const avgOverallScore = history.length > 0 
    ? Math.round(history.reduce((acc, curr) => acc + curr.scores.overall, 0) / history.length) 
    : 0;

  const calculateImprovement = () => {
    if (history.length < 2) return "+0%";
    const latest = history[0].scores.overall;
    const previous = history[1].scores.overall;
    const diff = latest - previous;
    return diff >= 0 ? `+${diff}%` : `${diff}%`;
  };
  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-2xl md:text-3xl font-display font-bold text-foreground">
          Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          AI-powered interview performance insights
        </p>
      </motion.div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <Link to="/interview">
          <motion.div
            whileHover={{ y: -2 }}
            className="bg-primary text-primary-foreground rounded-xl p-5 card-shadow-prominent cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-80">Start New</p>
                <p className="text-lg font-display font-semibold mt-1">
                  Mock Interview
                </p>
              </div>
              <ArrowRight className="w-5 h-5 opacity-70" />
            </div>
          </motion.div>
        </Link>
        <Link to="/resume">
          <motion.div
            whileHover={{ y: -2 }}
            className="bg-card border border-border rounded-xl p-5 card-shadow-elevated cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Upload</p>
                <p className="text-lg font-display font-semibold text-card-foreground mt-1">
                  Analyze Resume
                </p>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </motion.div>
        </Link>
        <Link to="/history">
          <motion.div
            whileHover={{ y: -2 }}
            className="bg-card border border-border rounded-xl p-5 card-shadow-elevated cursor-pointer"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">View</p>
                <p className="text-lg font-display font-semibold text-card-foreground mt-1">
                  Past Interviews
                </p>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </motion.div>
        </Link>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-card rounded-xl p-4 card-shadow border border-border flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Users className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="text-2xl font-display font-bold text-card-foreground">{history.length}</p>
            <p className="text-xs text-muted-foreground">Total Interviews</p>
          </div>
        </div>
        <div className="bg-card rounded-xl p-4 card-shadow border border-border flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
            <Target className="w-5 h-5 text-accent" />
          </div>
          <div>
            <p className="text-2xl font-display font-bold text-card-foreground">{avgOverallScore}%</p>
            <p className="text-xs text-muted-foreground">Avg. Score</p>
          </div>
        </div>
        <div className="bg-card rounded-xl p-4 card-shadow border border-border flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-info/10 flex items-center justify-center">
            <Clock className="w-5 h-5 text-info" />
          </div>
          <div>
            <p className="text-2xl font-display font-bold text-card-foreground">12m</p>
            <p className="text-xs text-muted-foreground">Avg. Duration</p>
          </div>
        </div>
        <div className="bg-card rounded-xl p-4 card-shadow border border-border flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-warning/10 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-warning" />
          </div>
          <div>
            <p className="text-2xl font-display font-bold text-card-foreground">{calculateImprovement()}</p>
            <p className="text-xs text-muted-foreground">Improvement</p>
          </div>
        </div>
      </div>

      {/* Score Cards + Gauge */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <ScoreCard
          title="Communication"
          score={latestResult.scores.communication}
          icon={MessageSquare}
          color="primary"
          delay={0}
        />
        <ScoreCard
          title="Confidence"
          score={latestResult.scores.confidence}
          icon={Shield}
          color="accent"
          delay={0.1}
        />
        <ScoreCard
          title="Technical Skills"
          score={latestResult.scores.technical}
          icon={Zap}
          color="warning"
          delay={0.2}
        />
        <HiringProbabilityGauge probability={latestResult.hiringProbability} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-xl p-6 card-shadow-elevated border border-border"
        >
          <h3 className="text-sm font-medium text-muted-foreground mb-4">
            Performance Trend
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
              <YAxis tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
              />
              <Bar dataKey="score" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Score" />
              <Bar dataKey="hiring" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} name="Hiring %" />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-card rounded-xl p-6 card-shadow-elevated border border-border"
        >
          <h3 className="text-sm font-medium text-muted-foreground mb-4">
            Skills Radar
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="hsl(var(--border))" />
              <PolarAngleAxis
                dataKey="subject"
                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
              />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10 }} />
              <Radar
                dataKey="value"
                stroke="hsl(var(--primary))"
                fill="hsl(var(--primary))"
                fillOpacity={0.2}
              />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </div>
  );
}
