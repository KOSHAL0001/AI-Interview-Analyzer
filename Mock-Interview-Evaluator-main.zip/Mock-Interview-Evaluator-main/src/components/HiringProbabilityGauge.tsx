import { motion } from "framer-motion";

interface Props {
  probability: number;
}

export default function HiringProbabilityGauge({ probability }: Props) {
  const getColor = (p: number) => {
    if (p >= 80) return "text-accent";
    if (p >= 60) return "text-primary";
    if (p >= 40) return "text-warning";
    return "text-destructive";
  };

  const getLabel = (p: number) => {
    if (p >= 80) return "Strong Hire";
    if (p >= 60) return "Likely Hire";
    if (p >= 40) return "Borderline";
    return "Needs Improvement";
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-card rounded-xl p-6 card-shadow-elevated border border-border text-center"
    >
      <h3 className="text-sm font-medium text-muted-foreground mb-6">Hiring Probability</h3>
      <div className="relative w-32 h-32 mx-auto mb-4">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
          <circle
            cx="60"
            cy="60"
            r="50"
            fill="none"
            stroke="hsl(var(--secondary))"
            strokeWidth="10"
          />
          <motion.circle
            cx="60"
            cy="60"
            r="50"
            fill="none"
            stroke="currentColor"
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={`${2 * Math.PI * 50}`}
            initial={{ strokeDashoffset: 2 * Math.PI * 50 }}
            animate={{
              strokeDashoffset: 2 * Math.PI * 50 * (1 - probability / 100),
            }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className={getColor(probability)}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-3xl font-display font-bold text-card-foreground">
            {probability}%
          </span>
        </div>
      </div>
      <p className={`text-sm font-semibold ${getColor(probability)}`}>
        {getLabel(probability)}
      </p>
    </motion.div>
  );
}
