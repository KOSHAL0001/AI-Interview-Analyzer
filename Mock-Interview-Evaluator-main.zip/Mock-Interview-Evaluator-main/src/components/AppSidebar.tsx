import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Mic,
  FileText,
  History,
  BarChart3,
  Brain,
} from "lucide-react";

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/interview", icon: Mic, label: "Mock Interview" },
  { to: "/resume", icon: FileText, label: "Resume Analyzer" },
  { to: "/history", icon: History, label: "Interview History" },
  { to: "/analytics", icon: BarChart3, label: "Analytics" },
];

export default function AppSidebar() {
  const location = useLocation();

  return (
    <aside className="hidden md:flex w-64 flex-col bg-sidebar border-r border-sidebar-border min-h-screen">
      <div className="p-6 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-sidebar-primary flex items-center justify-center">
          <Brain className="w-5 h-5 text-sidebar-primary-foreground" />
        </div>
        <span className="font-display text-xl font-bold text-sidebar-foreground">
          InterviewAI
        </span>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const isActive = location.pathname === item.to;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-primary"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
              }`}
            >
              <item.icon className="w-4.5 h-4.5" />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      <div className="p-4 mx-3 mb-4 rounded-lg bg-sidebar-accent">
        <p className="text-xs text-sidebar-foreground/60 font-medium">
          Powered by AI
        </p>
        <p className="text-xs text-sidebar-foreground/40 mt-1">
          Using advanced NLP for interview analysis
        </p>
      </div>
    </aside>
  );
}
