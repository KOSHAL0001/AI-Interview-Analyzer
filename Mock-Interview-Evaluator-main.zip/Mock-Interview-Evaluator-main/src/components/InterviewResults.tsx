import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { MessageSquare, Shield, Zap, Loader2, Download } from "lucide-react";
import ScoreCard from "@/components/ScoreCard";
import HiringProbabilityGauge from "@/components/HiringProbabilityGauge";
import { InterviewQuestion } from "@/lib/interview-data";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import jsPDF from "jspdf";
import { addInterviewResult } from "@/lib/interview-storage";

interface Props {
  questions: InterviewQuestion[];
  answers: string[];
  frames?: string[][];
  role: string;
  candidateName: string;
}

type AnalysisResult = {
  scores: { communication: number; confidence: number; technical: number; overall: number };
  hiringProbability: number;
  overallFeedback: string;
  improvementSuggestions: string[];
  questionFeedback: { question: string; transcript: string; score: number; feedback: string }[];
};

// ── Client-side fallback analyzer ──────────────────────────────────────────
function analyzeLocally(
  questions: InterviewQuestion[],
  answers: string[],
  role: string
): AnalysisResult {
  const questionFeedback = answers.map((answer, i) => {
    const q = questions[i];
    const text = answer.trim();
    const isNoSpeech = !text || text === "(No speech detected)";
    const words = isNoSpeech ? [] : text.split(/\s+/);
    const wordCount = words.length;
    const sentences = isNoSpeech ? [] : text.split(/[.!?]+/).filter(Boolean);
    const sentenceCount = sentences.length;
    const avgWordsPerSentence = sentenceCount > 0 ? wordCount / sentenceCount : 0;

    // Base score from response length
    let score: number;
    if (isNoSpeech) {
      score = 5;
    } else if (wordCount < 10) {
      score = 20 + Math.random() * 10;
    } else if (wordCount < 30) {
      score = 35 + Math.random() * 10;
    } else if (wordCount < 60) {
      score = 50 + Math.random() * 10;
    } else if (wordCount < 120) {
      score = 60 + Math.random() * 10;
    } else if (wordCount < 200) {
      score = 70 + Math.random() * 10;
    } else {
      score = 75 + Math.random() * 10;
    }

    // Sentence structure bonus
    if (avgWordsPerSentence >= 8 && avgWordsPerSentence <= 22) score += 5;

    // Keyword bonuses
    const lower = text.toLowerCase();
    const techKeywords = ["algorithm", "api", "database", "architecture", "performance", "scalable", "testing", "deploy", "ci/cd", "microservice", "component", "framework", "optimization", "cache", "async", "promise", "state", "hook", "query", "rest", "graphql"];
    const behavioralKeywords = ["team", "collaborate", "lead", "challenge", "outcome", "result", "learned", "improved", "initiative", "mentor", "stakeholder", "deadline", "priority"];
    const starKeywords = ["situation", "task", "action", "result"];

    const techHits = techKeywords.filter(k => lower.includes(k)).length;
    const behavHits = behavioralKeywords.filter(k => lower.includes(k)).length;
    const starHits = starKeywords.filter(k => lower.includes(k)).length;

    if (q?.category === "technical") score += Math.min(techHits * 3, 12);
    if (q?.category === "behavioral") score += Math.min(behavHits * 2.5, 10);
    if (q?.category === "situational") score += Math.min(starHits * 3, 12);
    score += Math.min((techHits + behavHits) * 1.5, 8);

    score = Math.round(Math.min(Math.max(score, 5), 95));

    // Generate feedback
    let feedback: string;
    if (isNoSpeech) {
      feedback = "No response was detected. Try speaking clearly toward the microphone and re-attempt. Even a short answer is better than silence.";
    } else if (score < 30) {
      feedback = `Your answer was very brief (${wordCount} words). Try to elaborate with specific examples, outcomes, and the reasoning behind your decisions.`;
    } else if (score < 50) {
      feedback = `Your response touched on the topic but lacked depth (${wordCount} words). Consider using the STAR method to structure your answer with concrete examples and measurable outcomes.`;
    } else if (score < 70) {
      feedback = `A reasonable answer with ${sentenceCount} sentences. To strengthen it, include specific metrics, technologies, or outcomes. Explain the "why" behind your decisions.`;
    } else if (score < 85) {
      feedback = `A solid response demonstrating good understanding. Your answer was well-structured with ${sentenceCount} sentences. To reach the next level, add more quantitative results and discuss trade-offs.`;
    } else {
      feedback = `Excellent, comprehensive answer with strong detail, good structure (${sentenceCount} sentences, ${wordCount} words), and relevant keywords. This would impress most interviewers.`;
    }

    return {
      question: q?.question || `Question ${i + 1}`,
      transcript: answer,
      score,
      feedback,
    };
  });

  const avgScore = questionFeedback.length > 0
    ? questionFeedback.reduce((sum, qf) => sum + qf.score, 0) / questionFeedback.length
    : 0;

  // Derive sub-scores with slight variance
  const communication = Math.round(Math.min(Math.max(avgScore + (Math.random() * 10 - 5), 5), 95));
  const confidence = Math.round(Math.min(Math.max(avgScore + (Math.random() * 12 - 6), 5), 95));
  const technical = Math.round(Math.min(Math.max(avgScore + (Math.random() * 8 - 4), 5), 95));
  const overall = Math.round((communication + confidence + technical) / 3);
  const hiringProbability = Math.round(Math.min(Math.max(overall + (Math.random() * 8 - 4), 5), 95));

  // Overall feedback based on score tier
  let overallFeedback: string;
  if (overall < 30) {
    overallFeedback = `The interview responses for the ${role} position were minimal. Most questions received very short or no answers. Focus on practicing aloud, structuring responses using the STAR method, and building comfort speaking about your experiences in detail.`;
  } else if (overall < 50) {
    overallFeedback = `The interview for the ${role} role showed some foundational knowledge but answers need more depth and specificity. Practice articulating your experiences with concrete examples, metrics, and clear reasoning to significantly improve your scores.`;
  } else if (overall < 70) {
    overallFeedback = `A reasonable performance for the ${role} position. Answers demonstrated understanding of core concepts but would benefit from stronger examples, more technical depth, and better-structured responses. Continue practicing with timed sessions to improve delivery.`;
  } else if (overall < 85) {
    overallFeedback = `Good interview performance for the ${role} role. Answers were generally well-structured with relevant examples. To move to the next level, focus on quantifying impact, discussing trade-offs, and demonstrating leadership and ownership in technical decisions.`;
  } else {
    overallFeedback = `Excellent interview performance for the ${role} role. Responses were detailed, well-structured, and demonstrated strong technical and communication skills. Minor refinements in delivery and conciseness could make you an even stronger candidate.`;
  }

  // Improvement suggestions
  const suggestions: string[] = [];
  if (communication < 70) suggestions.push("Practice articulating complex ideas concisely. Record yourself answering questions and review for filler words and clarity.");
  if (confidence < 70) suggestions.push("Work on maintaining steady eye contact with the camera and speaking with conviction. Pause instead of using filler words like 'um' or 'uh'.");
  if (technical < 70) suggestions.push("Strengthen technical depth by discussing system design patterns, architecture decisions, and specific technologies you've used with concrete examples.");
  if (questionFeedback.some(qf => qf.score < 40)) suggestions.push("Some questions received very short answers. Practice giving responses of at least 60-90 seconds with specific examples for each question.");
  suggestions.push("Use the STAR method (Situation, Task, Action, Result) to structure behavioral and situational answers for maximum impact.");
  if (overall < 60) suggestions.push("Consider doing more mock interviews to build comfort and fluency. Regular practice significantly improves interview performance.");
  suggestions.push("Review each question's feedback below and prepare stronger answers for similar questions in future interviews.");

  return {
    scores: { communication, confidence, technical, overall },
    hiringProbability,
    overallFeedback,
    improvementSuggestions: suggestions,
    questionFeedback,
  };
}

export default function InterviewResults({ questions, answers, frames = [], role, candidateName }: Props) {
  const [loading, setLoading] = useState(true);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const qa = answers.map((a, i) => ({
          question: questions[i]?.question || `Question ${i + 1}`,
          answer: a,
          frames: frames[i] || [],
        }));

        let analysisData: AnalysisResult | null = null;

        // Try the Edge Function first
        try {
          const { data, error } = await supabase.functions.invoke("analyze-interview", {
            body: { qa },
          });
          if (error) throw error;
          if (data?.error) throw new Error(data.error);

          const overall = Math.round((data.communication + data.confidence + data.technical) / 3);
          const parsedQuestionFeedback = qa.map((q, i) => ({
            question: q.question,
            transcript: q.answer,
            score: data.questionFeedback?.[i]?.score ?? 0,
            feedback: data.questionFeedback?.[i]?.feedback ?? "",
          }));

          analysisData = {
            scores: {
              communication: data.communication,
              confidence: data.confidence,
              technical: data.technical,
              overall,
            },
            hiringProbability: data.hiringProbability,
            overallFeedback: data.overallFeedback,
            improvementSuggestions: data.improvementSuggestions || [],
            questionFeedback: parsedQuestionFeedback,
          };
        } catch (edgeFnErr) {
          // Edge Function unavailable – use local analysis
          console.warn("Edge Function unavailable, using local analysis:", edgeFnErr);
          analysisData = analyzeLocally(questions, answers, role);
        }

        if (cancelled || !analysisData) return;

        setResult(analysisData);

        // Save to dynamic interview persistence storage
        addInterviewResult({
          candidateName,
          role,
          scores: analysisData.scores,
          hiringProbability: analysisData.hiringProbability,
          feedback: analysisData.overallFeedback,
          answers: analysisData.questionFeedback.map((qf, i) => ({
            questionId: i + 1,
            question: qf.question,
            transcript: qf.transcript,
            score: qf.score,
            feedback: qf.feedback,
          })),
        });

        toast.success("Interview analysis complete!");
      } catch (e: any) {
        // Final safety net – should not normally reach here
        console.error("Analysis failed entirely:", e);
        if (!cancelled) {
          const fallback = analyzeLocally(questions, answers, role);
          setResult(fallback);
          addInterviewResult({
            candidateName,
            role,
            scores: fallback.scores,
            hiringProbability: fallback.hiringProbability,
            feedback: fallback.overallFeedback,
            answers: fallback.questionFeedback.map((qf, i) => ({
              questionId: i + 1,
              question: qf.question,
              transcript: qf.transcript,
              score: qf.score,
              feedback: qf.feedback,
            })),
          });
          toast.success("Interview analysis complete (offline mode).");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [answers]);

  const exportPDF = () => {
    if (!result) return;
    const doc = new jsPDF();
    const margin = 14;
    let y = 20;
    doc.setFontSize(18);
    doc.text("InterviewAI Performance Report", margin, y);
    y += 10;
    doc.setFontSize(11);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, margin, y);
    y += 10;
    doc.setFontSize(13);
    doc.text("Scores", margin, y);
    y += 7;
    doc.setFontSize(11);
    doc.text(`Communication: ${result.scores.communication}/100`, margin, y); y += 6;
    doc.text(`Confidence: ${result.scores.confidence}/100`, margin, y); y += 6;
    doc.text(`Technical: ${result.scores.technical}/100`, margin, y); y += 6;
    doc.text(`Overall: ${result.scores.overall}/100`, margin, y); y += 6;
    doc.text(`Hiring Probability: ${result.hiringProbability}%`, margin, y); y += 10;
    doc.setFontSize(13);
    doc.text("AI Feedback", margin, y); y += 7;
    doc.setFontSize(10);
    const fb = doc.splitTextToSize(result.overallFeedback, 180);
    doc.text(fb, margin, y); y += fb.length * 5 + 6;
    doc.setFontSize(13);
    doc.text("Improvement Suggestions", margin, y); y += 7;
    doc.setFontSize(10);
    result.improvementSuggestions.forEach((s) => {
      const lines = doc.splitTextToSize(`• ${s}`, 180);
      if (y + lines.length * 5 > 280) { doc.addPage(); y = 20; }
      doc.text(lines, margin, y);
      y += lines.length * 5 + 2;
    });
    y += 4;
    doc.setFontSize(13);
    if (y > 260) { doc.addPage(); y = 20; }
    doc.text("Question Breakdown", margin, y); y += 7;
    doc.setFontSize(10);
    result.questionFeedback.forEach((q, i) => {
      if (y > 250) { doc.addPage(); y = 20; }
      const ql = doc.splitTextToSize(`Q${i + 1} (${q.score}/100): ${q.question}`, 180);
      doc.text(ql, margin, y); y += ql.length * 5 + 2;
      const fl = doc.splitTextToSize(`Feedback: ${q.feedback}`, 180);
      doc.text(fl, margin, y); y += fl.length * 5 + 6;
    });
    doc.save(`interview-report-${Date.now()}.pdf`);
  };

  if (loading) {
    return (
      <div className="p-8 max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-card rounded-xl p-12 card-shadow-elevated border border-border text-center"
        >
          <Loader2 className="w-10 h-10 text-primary animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-display font-semibold text-card-foreground mb-2">
            Analyzing Your Answers...
          </h2>
          <p className="text-muted-foreground text-sm">
            AI is evaluating communication, confidence, and technical knowledge
          </p>
        </motion.div>
      </div>
    );
  }

  if (!result) return null;

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
        <h1 className="text-2xl font-display font-bold text-foreground">Interview Results</h1>
        <p className="text-muted-foreground text-sm mt-1">AI-powered performance analysis</p>
      </motion.div>

      {/* Score Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <ScoreCard title="Communication" score={result.scores.communication} icon={MessageSquare} color="primary" delay={0} />
        <ScoreCard title="Confidence" score={result.scores.confidence} icon={Shield} color="accent" delay={0.1} />
        <ScoreCard title="Technical Skills" score={result.scores.technical} icon={Zap} color="warning" delay={0.2} />
        <HiringProbabilityGauge probability={result.hiringProbability} />
      </div>

      {/* Overall Feedback */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-card rounded-xl p-6 card-shadow-elevated border border-border mb-6"
      >
        <h3 className="text-sm font-medium text-muted-foreground mb-2">AI Feedback</h3>
        <p className="text-card-foreground">{result.overallFeedback}</p>
        {result.improvementSuggestions.length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium text-muted-foreground mb-2">Improvement Suggestions</h4>
            <ul className="space-y-1 list-disc list-inside text-sm text-card-foreground">
              {result.improvementSuggestions.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
          </div>
        )}
      </motion.div>

      {/* Per-Question Breakdown */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-card rounded-xl p-6 card-shadow-elevated border border-border mb-6"
      >
        <h3 className="text-sm font-medium text-muted-foreground mb-4">Question Breakdown</h3>
        <div className="space-y-4">
          {result.questionFeedback.map((qf, i) => (
            <div key={i} className="border border-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-card-foreground">Q{i + 1}: {qf.question}</span>
                <span className="text-xs font-mono px-2 py-0.5 bg-primary/10 text-primary rounded-full">
                  {qf.score}/100
                </span>
              </div>
              <p className="text-xs text-muted-foreground mb-1">Your answer:</p>
              <p className="text-sm text-secondary-foreground bg-secondary/50 rounded p-2 mb-2">
                {qf.transcript || "(No response)"}
              </p>
              <p className="text-sm text-muted-foreground italic">{qf.feedback}</p>
            </div>
          ))}
        </div>
      </motion.div>

      <div className="flex gap-3">
        <Link to="/">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
        <Link to="/interview">
          <Button>Try Again</Button>
        </Link>
        <Button onClick={exportPDF} variant="secondary" className="gap-2">
          <Download className="w-4 h-4" />
          Export PDF
        </Button>
      </div>
    </div>
  );
}
