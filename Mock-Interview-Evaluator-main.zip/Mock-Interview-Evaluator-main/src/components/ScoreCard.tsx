import { motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";

interface ScoreCardProps {
  title: string;
  score: number;
  icon: LucideIcon;
  color: "primary" | "accent" | "warning" | "info";
  delay?: number;
}

const colorMap = {
  primary: "bg-primary/10 text-primary",
  accent: "bg-accent/10 text-accent",
  warning: "bg-warning/10 text-warning",
  info: "bg-info/10 text-info",
};

const barColorMap = {
  primary: "bg-primary",
  accent: "bg-accent",
  warning: "bg-warning",
  info: "bg-info",
};

export default function ScoreCard({ title, score, icon: Icon, color, delay = 0 }: ScoreCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="bg-card rounded-xl p-5 card-shadow-elevated border border-border"
    >
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm font-medium text-muted-foreground">{title}</span>
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${colorMap[color]}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <div className="flex items-end gap-2 mb-3">
        <span className="text-3xl font-display font-bold text-card-foreground">{score}</span>
        <span className="text-sm text-muted-foreground mb-1">/100</span>
      </div>
      <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 0.8, delay: delay + 0.2, ease: "easeOut" }}
          className={`h-full rounded-full ${barColorMap[color]}`}
        />
      </div>
    </motion.div>
  );
}
