import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { role, techStack, count, existingQuestions } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY missing");

    const countToGenerate = count || 5;
    const existing = existingQuestions && existingQuestions.length > 0
      ? `Ensure you do NOT generate any questions that match or are highly similar to these already-asked questions:
${existingQuestions.map((q: string, idx: number) => `${idx + 1}. "${q}"`).join("\n")}`
      : "";

    const systemPrompt = `You are a world-class senior technical interviewer and hiring manager. Your task is to generate realistic, professional, and challenging mock interview questions.
Each question should be tailored to the candidate's target Job Role and Tech Stack / Skills.
Provide a balanced mix of technical, behavioral, and situational questions:
- Technical: coding concepts, system design, architectural decisions, performance optimization, best practices.
- Behavioral: communication, teamwork, dealing with ambiguity, leadership, problem-solving under stress.
- Situational: scenario-based problems (e.g. handling production issues, managing legacy code, working under tight deadlines).

Ensure the questions are engaging, professional, and sound like real-world questions from top tier tech companies (Google, Stripe, Netflix, etc.).
Assign appropriate timeLimit in seconds (typically 120 seconds for behavioral or situational, and 150 seconds for deep technical or architecture questions).`;

    const userPrompt = `Generate exactly ${countToGenerate} custom mock interview questions.
Target Job Role: ${role || "Software Engineer"}
Target Tech Stack / Focus Areas: ${techStack || "General Engineering Skills"}

${existing}

Please return the questions using the submit_questions function.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "submit_questions",
              description: "Submit the generated list of custom mock interview questions.",
              parameters: {
                type: "object",
                properties: {
                  questions: {
                    type: "array",
                    description: "The list of generated questions.",
                    items: {
                      type: "object",
                      properties: {
                        id: { type: "number", description: "Sequential ID (1, 2, 3...)" },
                        question: { type: "string", description: "The clear, complete interview question text." },
                        category: { 
                          type: "string", 
                          enum: ["technical", "behavioral", "situational"],
                          description: "The category classification of the question."
                        },
                        timeLimit: { 
                          type: "number", 
                          description: "Allowed response time in seconds (e.g. 120 or 150)." 
                        }
                      },
                      required: ["id", "question", "category", "timeLimit"]
                    }
                  }
                },
                required: ["questions"]
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "submit_questions" } },
      }),
    });

    if (response.status === 429) {
      return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (response.status === 402) {
      return new Response(JSON.stringify({ error: "AI credits exhausted. Please check Lovable workspace settings." }), {
        status: 402,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!response.ok) {
      const t = await response.text();
      console.error("Gateway error", response.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("No structured output returned");
    const result = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-questions error", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
