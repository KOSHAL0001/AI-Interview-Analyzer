import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { qa } = await req.json(); // qa: [{question, answer, frames?: string[]}]
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY missing");

    const systemPrompt = `You are an expert interview coach and hiring evaluator. Analyze the candidate's mock interview holistically:
- Communication: clarity, structure, vocabulary, articulation (from transcripts)
- Confidence: from facial expressions, posture, eye contact, and composure visible in the provided video frames; also tone from the answer text
- Technical: depth, accuracy, relevant examples
Score each 0-100. Provide actionable, specific feedback. Be honest but constructive. When video frames are provided, comment on observable non-verbal cues.`;

    // Build multimodal user message: text + images (frames)
    const contentParts: any[] = [
      {
        type: "text",
        text: `Evaluate this mock interview. For each question, the candidate's transcript follows, and a few sampled webcam frames are attached when available.\n\n${qa
          .map(
            (x: any, i: number) =>
              `Q${i + 1}: ${x.question}\nA: ${x.answer || "(no answer)"}${
                x.frames?.length ? `\n[${x.frames.length} video frame(s) attached below for Q${i + 1}]` : ""
              }`
          )
          .join("\n\n")}`,
      },
    ];

    // Attach at most 2 frames per question to keep payload reasonable
    for (let i = 0; i < qa.length; i++) {
      const q = qa[i];
      const fr: string[] = q.frames || [];
      if (!fr.length) continue;
      const sampled = fr.length <= 2 ? fr : [fr[0], fr[fr.length - 1]];
      for (const dataUrl of sampled) {
        contentParts.push({
          type: "image_url",
          image_url: { url: dataUrl },
        });
      }
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: contentParts },
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "submit_evaluation",
              description: "Submit interview evaluation scores and feedback.",
              parameters: {
                type: "object",
                properties: {
                  communication: { type: "number", description: "0-100" },
                  confidence: { type: "number", description: "0-100" },
                  technical: { type: "number", description: "0-100" },
                  hiringProbability: { type: "number", description: "0-100" },
                  overallFeedback: { type: "string" },
                  improvementSuggestions: {
                    type: "array",
                    items: { type: "string" },
                  },
                  questionFeedback: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        score: { type: "number" },
                        feedback: { type: "string" },
                      },
                      required: ["score", "feedback"],
                    },
                  },
                },
                required: [
                  "communication",
                  "confidence",
                  "technical",
                  "hiringProbability",
                  "overallFeedback",
                  "improvementSuggestions",
                  "questionFeedback",
                ],
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "submit_evaluation" } },
      }),
    });

    if (response.status === 429) {
      return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), {
        status: 429,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (response.status === 402) {
      return new Response(JSON.stringify({ error: "AI credits exhausted. Please add credits in workspace settings." }), {
        status: 402,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!response.ok) {
      const t = await response.text();
      console.error("Gateway error", response.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) throw new Error("No structured output returned");
    const result = JSON.parse(toolCall.function.arguments);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("analyze-interview error", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});